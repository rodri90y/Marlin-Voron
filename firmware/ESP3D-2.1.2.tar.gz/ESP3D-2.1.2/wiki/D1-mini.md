# D1 mini

Two Methods for connecting the Wemos d1 mini

---

## connection Wemos d1 mini and Logic Level Converter:

connection:
![level converter wireing](https://github.com/jayjojayson/ESP3D/blob/2.1/images/D1_mini/wemos-d1-mini_logic-level-converter.jpg)

example:
![end result](https://github.com/jayjojayson/ESP3D/blob/2.1/images/D1_mini/wemos-d1-mini_logic-level-converter-2.jpg)

printed case:<https://www.thingiverse.com/thing:4128593>

---

## connection Wemos d1 mini and Diode

connection:
![diode wireing diagram](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/D1_mini/FB_IMG_1510306696875.jpg)

example:
![end result](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/D1_mini/20171111_215253.jpg)

printed case:
<https://www.thingiverse.com/thing:2671591>
