# Where to connect on BIQU KFB2.0 (all in one Ramps1.4/Mega2560 R3 controller based)

![BIQU KFB2.0 board connection diagram](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/BIQU-KFB2.0/board.jpg)
