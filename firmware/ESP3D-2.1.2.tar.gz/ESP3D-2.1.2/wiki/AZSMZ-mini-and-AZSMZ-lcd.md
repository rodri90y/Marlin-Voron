# AZSMZ-mini and AZSMZ LCD boards

## Where to connect ESP on AZSMZ-mini board

![AZSMZ-mini board connection diagram](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/AZSMZ-mini/AZSMZ-mini.jpg)

If you don't have the soldering skills to grab the connectors from the unpopulated ethernet connection, you can also get 3.3v and GND from the ISP header (bottom left on the diagram above).

## Where to connect ESP on AZSMZ LCD

![AZSMZ-12864-LCD board connection diagram](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/AZSMZ-mini/AZSMZ-12864-LCD.jpg)
