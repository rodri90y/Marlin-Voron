# Where to connect ESP on MKS board (Smoothieware compatible version)

![MKS Smoothieware wiring diagram](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/MKS-SMOOTHIEWARE/MKS-smoothie.png)
