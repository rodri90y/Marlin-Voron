# Where to connect ESP on Azteeg X5 mini

![Azteeg X5 mini board connection diagram](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/AzteegX5-mini/azteeg.PNG)
