# Wiring NodeMCU V2/V3

![NodeMCU wiring diagram](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/NodeMCU/NodeMCU.PNG)
