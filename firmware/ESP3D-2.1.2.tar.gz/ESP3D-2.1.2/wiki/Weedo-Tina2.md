# Where to connect on Weedo Tina2 (Mega2560 based)

This printer is also brand labelled as **Monoprice MP cadet 3D printer**

![Weedo Tina2 connection diagram](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/TINA2/weedo_tina2.jpg)

In marlin this connection is **serial port 3**.

Note the Mega2560 is 5V powered and ESP is 3V3 powered.  
Internet in controversial but it seems that ESP32 is 5V tolerant on input pins so it should not be an issue.  
