# Where to connect ESP on Smoothieboard

![image](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/Smoothieware/smoothieboard-wiring.png)
