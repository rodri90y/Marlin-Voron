# Creality Ender 4

You will need to solder to small circle, or to the legs of the ATmega2560 (RXD0 pin 2, TXD0 pin 3)

![Ender 4 board connection diagram](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/ender4/board.jpg)
