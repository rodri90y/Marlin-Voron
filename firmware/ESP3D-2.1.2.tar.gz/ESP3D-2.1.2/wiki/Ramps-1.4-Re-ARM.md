# Where to connect ESP on RAMPS 1.4/Re-ARM

Ramps 1.4 can be used on Arduino Mega (repetier/marlin) and Re-ARM for ramps boards (smoothieware/marlin)
![image](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/RAMPS1.4/RAMPS.PNG)

Alternative pins if use Re-ARM (J4/UART port)

![image](https://i.ibb.co/cDMKGbK/Screenshot-20190803-022151.png)
