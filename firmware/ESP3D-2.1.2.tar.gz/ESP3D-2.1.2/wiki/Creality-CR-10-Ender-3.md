# Creality CR10 Ender 3

For the Sanguino based CR-10 and Ender printers you will need to solder to any of the via circled (can also be done in the backside of board), or to the legs of the Arduino or ftdi. Connect TX from the board to RX of Wemos D1 mini and RX from board to TX of Wemos D1 mini. 5v and GND are located in the six pin header next to the LCD connector.

![CR10 board connection diagram using vias](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/CR10/board.jpg)

Since soldering might be difficult because the solder points are so close to each other, another option is to scrape off the insulation from the traces on the backside and solder there. Be extra careful not to scrape the surrounding ground plane. You need suitable fine scraping tools for this. The picture below shows an Ender-2 PCB.

![CR10 board connection diagram using copper trace](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/CR10/traces.jpg)
