# Where to connect ESP on RADDS

![image](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/RADDS/RADDS.png)

## Result on Due/RADDS and Graphical LCD and repetier FW

![image](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/images/RADDS/screen.jpg)
