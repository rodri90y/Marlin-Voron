# Direct commands

* [v2.0](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/docs/Commands2_0.txt)
* [v2.1](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/docs/Commands2_1.txt)
* [v3.0](https://raw.githubusercontent.com/wiki/luc-github/ESP3D/docs/Commands3.txt)
